pub mod actions;

use next_web_core::{async_trait, error::BoxError};

use crate::state_machine::state_context::StateContext;

#[async_trait]
pub trait StateMachineAction<S, E>
where
    Self: Send + Sync,
{
    async fn execute(&self, context: &mut dyn StateContext<S, E>) -> Result<(), BoxError>;
}
