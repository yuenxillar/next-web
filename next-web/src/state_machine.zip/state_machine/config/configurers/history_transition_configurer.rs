use crate::state_machine::config::{
    builders::state_machine_transition_configurer::StateMachineTransitionConfigurer,
    configurer_builder::ConfigurerBuilder,
};

pub trait HistoryTransitionConfigurer<S, E>
where
    Self: ConfigurerBuilder<Box<dyn StateMachineTransitionConfigurer<S, E>>>,
{
    fn source(&mut self, source: S) -> &mut dyn HistoryTransitionConfigurer<S, E>;

    fn target(&mut self, target: S) -> &mut dyn HistoryTransitionConfigurer<S, E>;
}
