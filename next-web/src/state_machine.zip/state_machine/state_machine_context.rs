use std::fmt::Debug;

use next_web_core::messaging::message_headers::MessageHeaders;
use next_web_core::traits::message::Message;

use crate::state_machine::extended_state::ExtendedState;
use crate::state_machine::state::StateMachineState;
use crate::state_machine::transition::StateMachineTransition;
use crate::state_machine::StateMachine;

/// Represents the current context used in various stages of a state machine execution.
///
/// This context is provided to transitions, actions, and guards to give access
/// to events, headers, and extended state.
///
/// The context represents a snapshot of where the state machine is when this
/// context is passed to various methods, not the current state of the state machine.
pub trait StateMachineContext<S, E>
where
    Self: Send + Sync,
{
    /// Returns the stage this context is attached to.
    fn stage(&self) -> Stage;

    /// Returns the message associated with this context.
    ///
    /// May be `None` if the transition was not triggered by a signal.
    fn message(&self) -> Option<&dyn Message<E>>;

    /// Returns the event associated with this context.
    ///
    /// May be `None` if the transition was not triggered by a signal.
    fn event(&self) -> Option<&E>;

    /// Returns the event message headers.
    fn message_headers(&self) -> &MessageHeaders;

    /// Returns a specific message header.
    ///
    /// If the header key is not a `String`, the key's `Debug` representation is used.
    fn message_header(&self, header: &dyn Debug) -> Option<&dyn Debug>;

    /// Returns the state machine's extended state.
    fn extended_state(&self) -> &dyn ExtendedState;

    /// Returns the transition associated with this context.
    fn transition(&self) -> Option<&dyn StateMachineTransition<S, E>>;

    /// Returns the state machine instance.
    fn state_machine(&self) -> &dyn StateMachine<S, E>;

    /// Returns the source state of this context.
    ///
    /// Generally, the source is where the state machine is coming from,
    /// which may be different from the transition source.
    fn source(&self) -> Option<&dyn StateMachineState<S, E>>;

    /// Returns all source states of this context.
    ///
    /// Multiple sources are only valid during a context when the machine
    /// is joining from multiple orthogonal regions.
    fn sources(&self) -> Vec<&dyn StateMachineState<S, E>>;

    /// Returns the target state of this context.
    ///
    /// Generally, the target is where the state machine is going to,
    /// which may be different from the transition target.
    fn target(&self) -> Option<&dyn StateMachineState<S, E>>;

    /// Returns all target states of this context.
    ///
    /// Multiple targets are only valid during a context when the machine
    /// is forking into multiple orthogonal regions.
    fn targets(&self) -> Vec<&dyn StateMachineState<S, E>>;

    /// Returns the error associated with this context, if any.
    fn error(&self) -> Option<&dyn std::error::Error>;
}

pub enum Stage {
    EventNotAccepted,
    ExtendedStateChanged,
    StateChanged,
    StateEntry,
    StateExit,
    StatemachineError,
    StatemachineStart,
    StatemachineStop,
    Transition,
    TransitionStart,
    TransitionEnd,
}
