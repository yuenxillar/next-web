use std::marker::PhantomData;

#[derive(Clone)]
pub struct StateMachineHandlerCallHelper<S, E> {
    var: PhantomData<(S, E)>,
}

impl<S, E> Default for StateMachineHandlerCallHelper<S, E> {
    fn default() -> Self {
        Self { var: PhantomData }
    }
}
