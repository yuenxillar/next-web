/// TriggerListener for listening a Trigger events.
pub trait TriggerListener
where
    Self: Send + Sync,
{
    /// Notified when trigger has been triggered.
    fn triggered(&self);
}
