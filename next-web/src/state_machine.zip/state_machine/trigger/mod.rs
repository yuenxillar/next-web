use std::sync::Arc;

use next_web_core::async_trait;

use crate::state_machine::trigger::{
    trigger_context::TriggerContext, trigger_listener::TriggerListener,
};

pub mod trigger_context;
pub mod trigger_listener;

/// `Trigger` is the cause of the `Transition`. Cause is usually an
/// event but can be some other signal or a change in some condition.
///
/// This trait defines the interface for triggers that initiate state
/// transitions in a state machine. Triggers can be event-based,
/// timer-based, or condition-based.
///
/// # Type Parameters
/// - `S`: the type of state
/// - `E`: the type of event
#[async_trait]
pub trait Trigger<S, E>
where
    Self: Send + Sync,
{
    /// Evaluate trigger.
    ///
    /// # Arguments
    /// * `context` - the trigger context
    ///
    /// # Returns
    /// A future that resolves to `true` if trigger is fired, `false` otherwise
    async fn evaluate(&self, context: &dyn TriggerContext<S, E>) -> bool;

    /// Adds the trigger listener.
    ///
    /// # Arguments
    /// * `listener` - the listener
    fn add_trigger_listener(&mut self, listener: Arc<dyn TriggerListener>);

    /// Gets the event associated with this trigger. It is possible that there
    /// are no event association.
    ///
    /// # Returns
    /// The event associated with this trigger, if any
    fn event(&self) -> Option<&E>;

    /// Arm a trigger. After trigger has been armed a `TriggerListener`
    /// may receive events.
    fn arm(&mut self);

    /// Disarm a trigger. After trigger has been disarmed a `TriggerListener`
    /// will not receive events.
    fn disarm(&mut self);
}
