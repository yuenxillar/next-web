use std::sync::Arc;

use next_web_core::BoxFuture;

use crate::state_machine::access::state_machine_accessor::StateMachineAccessor;
use crate::state_machine::extended_state::ExtendedState;
use crate::state_machine::region::Region;
use crate::state_machine::state::StateMachineState;
use crate::state_machine::state_context::StateContext;

pub type BoxedStateAction<S, E> =
    Arc<dyn Fn(&mut dyn StateContext<S, E>) -> BoxFuture<'static, ()>>;
pub type BoxedStateGuard<S, E> =
    Arc<dyn Fn(&mut dyn StateContext<S, E>) -> BoxFuture<'static, bool>>;

/// Core trait for a generic finite state machine.
///
/// Provides APIs for basic operations like working with states, events, and lifecycle management.
pub trait StateMachine<S, E>
where
    Self: Region<S, E>,
{
    /// Returns the initial state of this state machine.
    fn initial_state(&self) -> &dyn StateMachineState<S, E>;

    /// Returns the extended state associated with this state machine.
    ///
    /// Extended state holds additional data that persists across state transitions.
    fn extended_state(&self) -> &dyn ExtendedState;

    /// Returns the state machine accessor for low-level operations.
    ///
    /// The accessor provides ways to modify the state machine structure and add listeners.
    fn state_machine_accessor(&self) -> &dyn StateMachineAccessor<S, E>;

    /// Sets an error condition on the state machine.
    ///
    /// When an error is set, the state machine will transition to an error state
    /// and reject further events until recovered.
    fn set_state_machine_error(&mut self, exception: Box<dyn std::error::Error>);

    /// Returns whether the state machine is in an error state.
    ///
    /// Returns `true` if [`set_state_machine_error`] has been called and the
    /// error hasn't been cleared.
    fn has_state_machine_error(&self) -> bool;
}

// impl<S, E> StateMachine<S, E>
// where
//     E: Send + Sync + 'static,
//     E: Clone + Debug + Hash + Eq,
//     S: Send + Sync + 'static,
//     S: Clone + Hash + Eq,
// {
//     pub fn from_configure(
//         configure: StateMachineConfigure<S, E>,
//         state_configure: StateMachineStateConfigure<S, E>,
//         transition_configure: StateMachineTransitionConfigure<S, E>,
//     ) -> Self {
//         Self {
//             id: String::default(),
//             configure,
//             state_configure,
//             transition_configure,
//             listener: None,
//             sender: None,
//             status: false,
//         }
//     }

//     pub async fn start(mut self) -> Arc<Self> {
//         // create manager
//         let mut manager = StateMachineManager::<S, E>::new(self.id.clone());

//         for configure in &self.transition_configure.inner {
//             manager
//                 .add_action(
//                     (self.id().into(), configure.transition()),
//                     configure.action(),
//                 )
//                 .await;
//         }

//         let (sender, receiver) = tokio::sync::broadcast::channel::<EventMessage<E>>(100);

//         self.status = true;
//         self.sender = Some(sender);

//         let state_machine = Arc::new(self);
//         manager.start_up(state_machine.clone(), receiver);

//         state_machine
//     }

//     pub async fn send_event(&self, message: EventMessage<E>) {
//         if !self.status {
//             return;
//         }
//         if let Some(sender) = self.sender.as_ref() {
//             if let Err(e) = sender.send(message) {
//                 error!("StateMachine [{}] send event error: {}", self.id(), e);
//                 sender.closed().await
//             }
//         }
//     }

//     pub fn id(&self) -> &str {
//         &self.id
//     }

//     pub fn initial_state(&self) -> &S {
//         &self.state_configure.initial_state()
//     }

//     pub fn states(&self) -> &HashSet<S> {
//         &self.state_configure.states
//     }

//     pub fn transitions(&self) -> &Vec<ExternalTransitionConfigure<S, E>> {
//         &self.transition_configure.inner
//     }

//     pub fn is_complete(&self) -> bool {
//         false
//     }

//     pub fn set_id(mut self, id: impl ToString) -> Self {
//         self.id = id.to_string();
//         self
//     }

//     pub fn add_state_listener<L>(mut self, listener: L) -> Self
//     where
//         L: StateMachineListener<S, E> + 'static,
//     {
//         self.listener = Some(Box::new(listener));
//         self
//     }

//     pub fn remove_state_listener(&mut self) {
//         self.listener = None;
//     }
// }

// impl<S, E> Default for StateMachine<S, E>
// where
//     S: Default,
//     E: Default,
// {
//     fn default() -> Self {
//         Self {
//             id: Default::default(),
//             configure: Default::default(),
//             state_configure: Default::default(),
//             transition_configure: Default::default(),
//             listener: Default::default(),
//             sender: Default::default(),
//             status: Default::default(),
//         }
//     }
// }

// #[async_trait]
// pub trait StateMachineAction<S, E>: DynClone + Send + Sync
// where
//     S: Clone,
//     E: Clone,
// {
//     fn transition(&self) -> Transition<S, E>;

//     async fn execute(&mut self, context: StateContext<S, E>);
// }

// next_web_core::clone_trait_object!(<S, E> StateMachineAction<S, E> where S: Clone , E: Clone,);

// #[async_trait]
// pub trait StateMachineListener<S, E>: DynClone + Send + Sync {
//     async fn state_changed(&self, from: S, to: S, event: E);

//     async fn event_not_accepted(&self, event: EventMessage<E>);
// }

// next_web_core::clone_trait_object!(<S, E> StateMachineListener<S, E> where S: Clone , E: Clone,);

// #[derive(Clone, PartialEq, Eq, Hash)]
// pub struct State<S, E> {
//     pub source: S,
//     pub event: E,
// }

// impl<S, E> Into<State<S, E>> for (S, E) {
//     fn into(self) -> State<S, E> {
//         State {
//             source: self.0,
//             event: self.1,
//         }
//     }
// }

// #[derive(Clone, PartialEq, Eq, Hash)]
// pub struct Transition<S, E> {
//     pub source: S,
//     pub target: S,
//     pub event: E,
// }

// #[derive(Debug, Clone)]
// pub struct EventMessage<E> {
//     pub(crate) event: E,
//     pub(crate) payload: Option<AnyValue>,
// }

// impl<E> EventMessage<E> {
//     pub fn new(event: E, payload: AnyValue) -> Self {
//         Self {
//             event,
//             payload: Some(payload),
//         }
//     }

//     pub fn payload(&self) -> Option<&AnyValue> {
//         self.payload.as_ref()
//     }

//     pub fn event(&self) -> &E {
//         &self.event
//     }

//     pub fn set_payload(mut self, payload: AnyValue) -> Self {
//         self.payload = Some(payload);
//         self
//     }

//     pub fn set_event(mut self, event: E) -> Self {
//         self.event = event;
//         self
//     }
// }

// impl<E> Default for EventMessage<E>
// where
//     E: Default,
// {
//     fn default() -> Self {
//         Self {
//             event: Default::default(),
//             payload: None,
//         }
//     }
// }
