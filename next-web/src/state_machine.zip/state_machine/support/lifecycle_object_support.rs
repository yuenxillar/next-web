use next_web_core::{async_trait, error::BoxError};

#[derive(Clone)]
pub struct LifecycleObjectSupport {}

impl Default for LifecycleObjectSupport {
    fn default() -> Self {
        Self {}
    }
}

#[async_trait]
pub trait LifecycleObjectSupportExt {
    fn on_init(&mut self) -> Result<(), BoxError>;

    async fn do_pre_start_reactively(&self);

    async fn do_pre_stop_reactively(&self);

    // async fn do_post_start_reactively(&self);
}
