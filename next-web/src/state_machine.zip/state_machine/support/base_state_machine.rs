use futures::future::TryFutureExt;
use next_web_core::error::BoxError;
use next_web_core::traits::message::Message;
use std::collections::HashMap;
use std::fmt::{self, Debug};
use std::hash::Hash;
use std::ops::{Deref, DerefMut};
use std::sync::{Arc, RwLock};
use tracing::{debug, info};
use uuid::Uuid;

use crate::state_machine::extended_state::ExtendedState;
use crate::state_machine::listener::state_machine_listener::StateMachineListener;
use crate::state_machine::monitor::state_machine_monitor::StateMachineMonitor;
use crate::state_machine::state::pseudo_state::PseudoState;
use crate::state_machine::state::pseudo_state_kind::PseudoStateKind;
use crate::state_machine::state::StateMachineState;
use crate::state_machine::state_context::{Stage, StateContext};
use crate::state_machine::state_machine_context::StateMachineContext;
use crate::state_machine::state_machine_event_result::{
    DefaultStateMachineEventResult, StateMachineEventResult,
};
use crate::state_machine::support::default_extended_state::DefaultExtendedState;
use crate::state_machine::support::default_state_context::DefaultStateContext;
use crate::state_machine::support::state_machine_executor::StateMachineExecutor;
use crate::state_machine::support::state_machine_interceptor::StateMachineInterceptor;
use crate::state_machine::support::state_machine_object_support::StateMachineObjectSupport;
use crate::state_machine::transition::initial_transition::InitialTransition;
use crate::state_machine::transition::transition_conflict_policy::TransitionConflictPolicy;
use crate::state_machine::transition::StateMachineTransition;
use crate::state_machine::StateMachine;

/// These will be imported by the user
pub struct BaseStateMachine<S, E> {
    states: Vec<Arc<dyn StateMachineState<S, E>>>,
    transitions: Vec<Arc<dyn StateMachineTransition<S, E>>>,
    initial_state: Arc<dyn StateMachineState<S, E>>,
    initial_transition: Arc<dyn StateMachineTransition<S, E>>,
    initial_event: Option<Box<dyn Message<E>>>,
    extended_state: Arc<RwLock<dyn ExtendedState>>,
    transition_conflict_policy: Option<TransitionConflictPolicy>,
    current_state: Option<Arc<dyn StateMachineState<S, E>>>,
    last_state: Option<Arc<dyn StateMachineState<S, E>>>,
    current_error: Option<BoxError>,
    history: Option<Arc<dyn PseudoState<S, E>>>,
    trigger_to_transition: HashMap<String, Arc<dyn StateMachineTransition<S, E>>>,
    triggerless_transitions: Vec<Arc<dyn StateMachineTransition<S, E>>>,
    relay: Option<Arc<dyn StateMachine<S, E>>>,
    state_machine_executor: Option<Box<dyn StateMachineExecutor<S, E>>>,
    initial_enabled: Option<bool>,
    uuid: Uuid,
    id: Option<String>,
    forwarded_initial_event: Option<Box<dyn Message<E>>>,
    parent_machine: Option<Arc<dyn StateMachine<S, E>>>,

    object_support: StateMachineObjectSupport<S, E>,
}

impl<S, E> BaseStateMachine<S, E>
where
    S: Send + Sync,
    S: 'static,
    E: Send + Sync,
    E: 'static,
{
    pub fn new(
        states: Vec<Arc<dyn StateMachineState<S, E>>>,
        transitions: Vec<Arc<dyn StateMachineTransition<S, E>>>,
        initial_state: Arc<dyn StateMachineState<S, E>>,
    ) -> Self {
        Self::with_extended_state(
            states,
            transitions,
            initial_state,
            Arc::new(RwLock::new(DefaultExtendedState::default())),
        )
    }

    pub fn with_extended_state(
        states: Vec<Arc<dyn StateMachineState<S, E>>>,
        transitions: Vec<Arc<dyn StateMachineTransition<S, E>>>,
        initial_state: Arc<dyn StateMachineState<S, E>>,
        extended_state: Arc<RwLock<dyn ExtendedState>>,
    ) -> Self {
        Self::with_all(
            states,
            transitions,
            initial_state,
            None,
            None,
            extended_state,
            None,
        )
    }

    pub fn with_all(
        states: Vec<Arc<dyn StateMachineState<S, E>>>,
        transitions: Vec<Arc<dyn StateMachineTransition<S, E>>>,
        initial_state: Arc<dyn StateMachineState<S, E>>,
        initial_transition: Option<Arc<dyn StateMachineTransition<S, E>>>,
        initial_event: Option<Box<dyn Message<E>>>,
        extended_state: Arc<RwLock<dyn ExtendedState>>,
        uuid: Option<Uuid>,
    ) -> Self {
        let uuid = uuid.unwrap_or_else(Uuid::new_v4);

        let initial_transition = initial_transition
            .unwrap_or_else(|| Arc::new(InitialTransition::new(initial_state.clone())));

        BaseStateMachine {
            states,
            transitions,
            initial_state,
            initial_transition,
            initial_event,
            extended_state,
            transition_conflict_policy: None,
            current_state: None,
            last_state: None,
            current_error: None,
            history: None,
            trigger_to_transition: HashMap::new(),
            triggerless_transitions: Vec::new(),
            relay: None,
            state_machine_executor: None,
            initial_enabled: None,
            uuid,
            id: None,
            forwarded_initial_event: None,
            parent_machine: None,
            object_support: Default::default(),
        }
    }

    pub async fn on_init(&mut self) -> Result<(), Box<dyn std::error::Error>> {
        // Validate initial state
        assert!(
            self.initial_state.pseudo_state().is_some()
                && self.initial_state.pseudo_state().unwrap().get_kind()
                    == PseudoStateKind::Initial,
            "Initial state's pseudostate kind must be INITIAL"
        );

        self.last_state = None;

        // Process transitions
        let mut trigger_to_transition = HashMap::new();
        let mut triggerless_transitions = Vec::new();

        for transition in &self.transitions {
            if let Some(trigger) = transition.trigger() {
                trigger_to_transition.insert(trigger.id(), transition.clone());
            } else {
                triggerless_transitions.push(transition.clone());
            }
        }

        // This would need interior mutability or to be done in a different way
        // For now, we'll skip actually setting these fields

        // Create executor
        let executor = ReactiveStateMachineExecutor::new(
            self,
            self.get_relay_state_machine(),
            self.transitions.clone(),
            trigger_to_transition,
            triggerless_transitions,
            self.initial_transition.clone(),
            self.initial_event.clone(),
            self.transition_conflict_policy,
        );

        self.state_machine_executor = Some(Box::new(executor));

        Ok(())
    }

    pub async fn send_event(&self, event: Box<dyn Message<E>>) -> bool {
        // Simplified implementation
        if self.has_state_machine_error().await {
            return false;
        }

        let event = self.pre_event(event).await;
        self.accept_event(event).await
    }

    pub async fn send_events(
        &self,
        events: Vec<Box<dyn Message<E>>>,
    ) -> Vec<StateMachineEventResult<S, E>> {
        let mut results = Vec::new();
        for event in events {
            results.push(self.handle_event(event).await);
        }
        results
    }

    async fn handle_event(&self, event: Box<dyn Message<E>>) -> StateMachineEventResult<S, E> {
        if self.has_state_machine_error().await {
            return StateMachineEventResult::denied(self, event);
        }

        let event = self.pre_event(event).await;
        self.accept_event(event).await;

        DefaultStateMachineEventResult::accepted(self, event)
    }

    async fn pre_event(&self, event: Box<dyn Message<E>>) -> Box<dyn Message<E>> {
        // Apply interceptors
        let mut event = event;
        for interceptor in self.state_machine_interceptors.iter() {
            event = interceptor.pre_event(event, self).await;
        }
        event
    }

    async fn accept_event(&self, event: Box<dyn Message<E>>) -> bool {
        let current_state_opt = self.current_state.clone();

        if let Some(current_state) = current_state_opt {
            if current_state.should_defer(&event).await {
                // Queue deferred event
                if let Some(executor) = self.state_machine_executor.as_ref() {
                    executor.queue_deferred_event(event).await;
                }
                return false;
            }

            // Send event to current state
            if current_state.send_event(event.clone()).await {
                return true;
            }

            // Check transitions
            for transition in &self.transitions {
                if let Some(trigger) = transition.trigger() {
                    if transition.source().ids().contains(&current_state.id()) {
                        if trigger.evaluate(event.payload().clone()).await {
                            if let Some(executor) = self.state_machine_executor.as_ref() {
                                executor.queue_event(event).await;
                                return true;
                            }
                        }
                    }
                }
            }
        }

        self.notify_event_not_accepted(event).await;
        false
    }

    async fn notify_event_not_accepted(&self, event: Box<dyn Message<E>>) {
        if self.parent_machine.is_none() {
            // Notify listeners
            for listener in self.object_support.iter() {
                listener.event_not_accepted(event.clone()).await;
            }
        }
    }

    async fn notify_state_machine_started(&self) {
        let context = self.build_state_context(
            Stage::StateMachineStart,
            None,
            None,
            self.get_relay_state_machine(),
        );

        for listener in self.state_listeners.iter() {
            listener.state_machine_started(context.clone()).await;
        }
    }

    async fn notify_state_machine_stopped(&self) {
        let context = self.build_state_context(Stage::StateMachineStop, None, None, self);

        for listener in self.state_listeners.iter() {
            listener.state_machine_stopped(context.clone()).await;
        }
    }

    async fn notify_state_machine_error(&self, error: Box<dyn std::error::Error + Send + Sync>) {
        let context =
            self.build_state_context_with_error(Stage::StateMachineError, None, None, self, error);

        for listener in self.state_listeners.iter() {
            listener.state_machine_error(context.clone()).await;
        }
    }

    fn build_state_context(
        &self,
        stage: Stage,
        message: Option<Box<dyn Message<E>>>,
        transition: Option<Arc<dyn StateMachineTransition<S, E>>>,
        state_machine: Arc<dyn StateMachine<S, E>>,
    ) -> Arc<dyn StateContext<S, E>> {
        Arc::new(DefaultStateContext::new(
            stage,
            message,
            self.extended_state.clone(),
            transition,
            state_machine,
            None,
            None,
            None,
        ))
    }

    fn build_state_context_with_error(
        &self,
        stage: Stage,
        message: Option<Box<dyn Message<E>>>,
        transition: Option<Arc<dyn StateMachineTransition<S, E>>>,
        state_machine: Arc<dyn StateMachine<S, E>>,
        error: Box<dyn std::error::Error + Send + Sync>,
    ) -> Arc<dyn StateContext<S, E>> {
        DefaultStateContext::new_with_error(
            stage,
            message,
            self.extended_state.clone(),
            transition,
            state_machine,
            error,
        )
    }

    fn get_relay_state_machine(&self) -> Arc<dyn StateMachine<S, E>> {
        self.relay.clone().unwrap_or_else(|| Arc::new(self.clone()))
    }

    pub async fn get_state(&self) -> Option<Arc<dyn StateMachineState<S, E>>> {
        if self.is_complete().await {
            self.last_state.clone()
        } else {
            self.current_state.clone()
        }
    }

    pub async fn start(&self) -> Result<(), Box<dyn std::error::Error>> {
        if self.current_state.is_some() {
            debug!("State already set, disabling initial");
            self.register_pseudo_state_listener().await;
            if let Some(executor) = self.state_machine_executor.as_ref() {
                executor.set_initial_enabled(false);
            }
        } else {
            self.do_start().await?;
            self.register_pseudo_state_listener().await;

            if let Some(executor) = self.state_machine_executor.as_ref() {
                if let Some(initial_enabled) = self.initial_enabled.as_ref() {
                    if !initial_enabled {
                        debug!("Initial disable asked, disabling initial");
                        executor.set_initial_enabled(false);
                    } else {
                        executor.set_forwarded_initial_event(self.forwarded_initial_event.clone());
                    }
                }
            }
        }

        if let Some(executor) = self.state_machine_executor.as_ref() {
            executor.start().await?;
        }

        self.notify_state_machine_started().await;
        Ok(())
    }

    async fn do_start(&self) -> Result<(), Box<dyn std::error::Error>> {
        // Base start logic
        Ok(())
    }

    pub async fn stop(&self) -> Result<(), Box<dyn std::error::Error>> {
        self.notify_state_machine_stopped().await;

        // Stash current state before nulling it
        self.last_state = self.current_state.clone();
        self.current_state = None;
        self.initial_enabled = None;

        debug!("Stop complete");

        if let Some(executor) = self.state_machine_executor.as_ref() {
            executor.stop().await?;
        }

        Ok(())
    }

    pub async fn is_complete(&self) -> bool {
        if let Some(state) = self.current_state.as_ref() {
            if let Some(pseudo_state) = state.pseudo_state() {
                return pseudo_state.get_kind() == PseudoStateKind::End;
            }
        }
        !self.is_running().await
    }

    pub async fn is_running(&self) -> bool {
        // Simplified - would need actual running state tracking
        self.current_state.is_some()
    }

    async fn register_pseudo_state_listener(&self) {
        for state in &self.states {
            if let Some(pseudo_state) = state.pseudo_state() {
                let listeners = vec![Arc::new(PseudoStateListenerImpl::new(
                    self.clone(),
                    pseudo_state.clone(),
                ))];
                // Would need to set listeners on pseudo_state
            }
        }
    }

    pub fn add_state_listener(&self, listener: Arc<dyn StateMachineListener<S, E>>) {
        self.state_listeners.push(listener);
    }

    pub fn remove_state_listener(&self, listener: Arc<dyn StateMachineListener<S, E>>) {
        self.state_listeners
            .write()
            .unwrap()
            .retain(|l| !Arc::ptr_eq(l, &listener));
    }

    pub async fn set_state_machine_error(
        &self,
        exception: Option<Box<dyn std::error::Error + Send + Sync>>,
    ) {
        let exception = if let Some(exception) = exception {
            // Apply interceptors
            let mut exception = exception;
            for interceptor in self.state_machine_interceptors.iter() {
                exception = interceptor.state_machine_error(self, exception).await;
            }
            Some(exception)
        } else {
            None
        };

        *self.current_error = exception;

        if let Some(error) = self.current_error.as_ref() {
            self.notify_state_machine_error(error.clone()).await;
        }
    }

    pub async fn has_state_machine_error(&self) -> bool {
        self.current_error.is_some()
    }

    pub fn get_states(&self) -> Vec<Arc<dyn StateMachineState<S, E>>> {
        self.states.clone()
    }

    pub fn get_transitions(&self) -> Vec<Arc<dyn StateMachineTransition<S, E>>> {
        self.transitions.clone()
    }

    pub fn set_initial_enabled(&mut self, enabled: bool) {
        self.initial_enabled = Some(enabled);
    }

    pub fn get_uuid(&self) -> Uuid {
        self.uuid
    }

    pub fn get_id(&self) -> Option<&str> {
        self.id.as_deref()
    }

    pub fn set_id(&mut self, id: impl Into<String>) {
        self.id = Some(id.into());
    }

    pub fn set_relay(&mut self, state_machine: Arc<dyn StateMachine<S, E>>) {
        self.relay = Some(state_machine);
    }

    pub fn set_parent_machine(&mut self, parent_machine: Arc<dyn StateMachine<S, E>>) {
        self.parent_machine = Some(parent_machine);
    }

    pub fn set_forwarded_initial_event(&mut self, message: Box<dyn Message<E>>) {
        self.forwarded_initial_event = Some(message);
    }

    pub async fn reset_state_machine(
        &self,
        state_machine_context: &dyn StateMachineContext<S, E>,
    ) -> Result<(), Box<dyn std::error::Error>> {
        self.reset_state_machine_reactively(state_machine_context)
            .await
    }

    pub async fn reset_state_machine_reactively(
        &self,
        context: &dyn StateMachineContext<S, E>,
    ) -> Result<(), Box<dyn std::error::Error>>
    where
        S: Eq + Hash,
    {
        // debug!("Request to reset state machine: {:?}", context);
        self.set_id(context.id());

        let state_id = context.state();
        for state in &self.states {
            for substate in state.states() {
                if substate.ids().contains(&state_id) {
                    self.current_state = Some(state.clone());
                    self.last_state = Some(state.clone());

                    // Reset extended state
                    let extended_state_context = context.extended_state();
                    let mut ext_state = self.extended_state;
                    ext_state.variables().clear();
                    for (k, v) in extended_state_context.variables() {
                        ext_state.variables().insert(k.clone(), v.clone());
                    }

                    debug!("State reset");
                    break;
                }
            }
        }

        if let Some(history_state) = self.history.as_ref() {
            let history_states = context.history_states();
            for (key, state_id) in history_states {
                for h in self.get_states() {
                    if h.id() == state_id {
                        // Would need to set history state
                        break;
                    }
                }
            }
        } else {
            info!("Got null context, resetting to initial state");
            self.current_state = Some(self.initial_state.clone());
            self.extended_state.variables().clear();
            self.set_id(String::new());
        }

        Ok(())
    }

    pub fn add_state_machine_interceptor(
        &mut self,
        interceptor: Arc<dyn StateMachineInterceptor<S, E>>,
    ) {
        self.object_support
            .state_machine_interceptors
            .push(interceptor);
    }

    pub fn add_state_machine_monitor(&mut self, monitor: Arc<dyn StateMachineMonitor<S, E>>) {
        self.state_machine_monitors.push(monitor);
    }
}

impl<S, E> Clone for BaseStateMachine<S, E>
where
    S: Clone + Eq + Hash + Send + Sync + 'static,
    E: Clone + Eq + Hash + Send + Sync + 'static,
{
    fn clone(&self) -> Self {
        BaseStateMachine {
            states: self.states.clone(),
            transitions: self.transitions.clone(),
            initial_state: self.initial_state.clone(),
            initial_transition: self.initial_transition.clone(),
            initial_event: self.initial_event.clone(),
            extended_state: self.extended_state.clone(),
            transition_conflict_policy: self.transition_conflict_policy,
            current_state: self.current_state.clone(),
            last_state: self.last_state.clone(),
            current_error: self.current_error.clone(),
            history: self.history.clone(),
            trigger_to_transition: self.trigger_to_transition.clone(),
            triggerless_transitions: self.triggerless_transitions.clone(),
            relay: self.relay.clone(),
            state_machine_executor: self.state_machine_executor.clone(),
            initial_enabled: self.initial_enabled.clone(),
            uuid: self.uuid,
            id: self.id.clone(),
            forwarded_initial_event: self.forwarded_initial_event.clone(),
            parent_machine: self.parent_machine.clone(),

            object_support: Default::default(),
        }
    }
}

impl<S, E> fmt::Display for BaseStateMachine<S, E>
where
    S: Debug,
    S: Send + Sync,
    E: Send + Sync,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut buf = String::new();
        for state in &self.states {
            for s in state.states() {
                buf.push_str(&format!("{:?} ", s.id()));
            }
        }
        buf.push_str(" / ");

        if let Some(current) = self.current_state.as_ref() {
            buf.push_str(&format!("{:?}", current.ids()));
        }

        buf.push_str(" / uuid=");
        buf.push_str(&self.uuid.to_string());
        buf.push_str(" / id=");
        if let Some(id) = self.id.as_ref() {
            buf.push_str(id);
        }

        write!(f, "{}", buf)
    }
}

impl<S, E> Deref for BaseStateMachine<S, E> {
    type Target = StateMachineObjectSupport<S, E>;
    fn deref(&self) -> &Self::Target {
        &self.object_support
    }
}

impl<S, E> DerefMut for BaseStateMachine<S, E> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        &mut self.object_support
    }
}
